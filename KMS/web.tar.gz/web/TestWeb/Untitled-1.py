# %%
# !pip install torch torchvision torchaudio
# !pip install pytorch-forecasting
# !pip install requests
# !pip install fastparquet
# !pip install --no-cache --force optuna==3.4.0 torch==2.1.0
# !pip install --no-cache --force torch==2.0.1 pytorch-lightning==2.0.2 pytorch_forecasting==1.0.0 torchaudio==2.0.2 torchdata==0.6.1 torchtext==0.15.2 torchvision==0.15.2 optuna==3.4
# !pip install torchmetrics
# !pip install seaborn

# %%
import os
import warnings
import seaborn as sns
warnings.filterwarnings("ignore")

# %%
import copy
from pathlib import Path
import warnings

import lightning.pytorch as pl
from lightning.pytorch.callbacks import EarlyStopping, LearningRateMonitor
from lightning.pytorch.loggers import TensorBoardLogger
import numpy as np
import pandas as pd
import torch
from pytorch_forecasting import Baseline, TemporalFusionTransformer, TimeSeriesDataSet
from pytorch_forecasting.data import GroupNormalizer
from pytorch_forecasting.metrics import MAE, SMAPE, QuantileLoss, PoissonLoss


# %%
from sqlalchemy import create_engine, Connection, text
import pandas as pd

engine = create_engine('mysql+pymysql://root:kdt5@localhost:3306/Team2?charset=utf8mb4')

with engine.begin() as conn:
    data = pd.read_sql(text('SELECT * FROM BTCUSDT_1d_latest'), conn)
    vix = pd.read_sql(text('SELECT * FROM vix'), conn)
    t20y = pd.read_sql(text('SELECT * FROM treasury_20y'), conn)
    oil = pd.read_sql(text('SELECT * FROM wti_oil_price'), conn)
    coinbase = pd.read_sql(text('SELECT * FROM hist_coin'), conn)
    microstr = pd.read_sql(text('SELECT * FROM hist_mstr'), conn)

COINBASE = True

data = pd.merge(data, vix, left_on='timestamp', right_on='date', how='left', suffixes=('', '_vix'))
data = pd.merge(data, t20y, left_on='timestamp', right_on='Date', how='left', suffixes=('', '_t20y'))
data = pd.merge(data, oil, left_on='timestamp', right_on='DATE', how='left', suffixes=('', '_oil'))
data

# %%
import yfinance as yf

coin = yf.Ticker('COIN')
microstrategy = yf.Ticker('MSTR')
coin.info

hist_coin = coin.history(period = '9y', interval = '1d')
hist_mstr = microstrategy.history(period = '9y', interval = '1d')


# %%
hist_coin.reset_index(inplace=True)
hist_mstr.reset_index(inplace=True)

# %%
hist_coin['Date'] = hist_coin['Date'].dt.strftime('%Y-%m-%d')
hist_coin['Date'] = pd.to_datetime(hist_coin['Date'])
hist_coin.columns = [x.lower() for x in hist_coin.columns]

hist_mstr.columns = [x.lower() for x in hist_mstr.columns]
hist_mstr['date'] = hist_mstr['date'].dt.strftime('%Y-%m-%d')
hist_mstr['date'] = pd.to_datetime(hist_mstr['date'])

# %% [markdown]
# ### Yfinance 데이터 추가

# %%
if COINBASE:
    data = pd.merge(data, hist_coin, left_on='timestamp', right_on='date', how='left', suffixes=('', '_coinbase'))

# %%
data.columns

# %%
sns.lineplot(data, x='timestamp', y='DCOILWTICO')

# %%
data.interpolate(method='linear', inplace=True)

# %%
data['time_idx'] = data.index
data['time_idx'] -= data['time_idx'].min()
data['pairs'] = 'BTCUSDT'

# %%
data['month'] = data.timestamp.dt.month.astype(str).astype('category')
# data['log_volume'] = np.log(data.volume + 1e-8)
# data['avg_volume_by_sku'] = data.groupby(['time_idx', 'sku'], observed=True).volume.transform('mean')
# data['avg_volume_by_agency'] = data.groupby(['time_idx', 'agency'], observed=True).volume.transform('mean')

# %%
data['diff'] = (data['close']-data['open']).div(data['open'])
data['diff_vix'] = (data['close_vix']-data['open_vix']).div(data['open_vix'])

if COINBASE:
    data['diff_coinbase'] = (data['close_coinbase']-data['open_coinbase']).div(data['open_coinbase'])

# %%
# we want to encode special days as one variable and thus need to first reverse one-hot encoding
# special_days = [
#     "easter_day",
#     "good_friday",
#     "new_year",
#     "christmas",
#     "labor_day",
#     "independence_day",
#     "revolution_day_memorial",
#     "regional_games",
#     "fifa_u_17_world_cup",
#     "football_gold_cup",
#     "beer_capital",
#     "music_fest",
# ]

# data[special_days] = data[special_days].apply(lambda x: x.map({0: '-', 1: x.name})).astype('category')


# %%
# !pip install holidays
import holidays

en_holidays = holidays.UnitedStates()
cn_holidays = holidays.China()
holidf = pd.DataFrame(columns=['date', 'isholiday'])
holidf['date'] = data['timestamp']
holidf['isholiday'] = holidf['date'].apply(lambda x: 'yes' if x in en_holidays or x in cn_holidays else 'no')
holidf['isholiday'].value_counts()
data['isholiday'] = holidf['isholiday']

# %%
if 'close_coinbase' in data.columns:
    data.dropna(inplace=True)

# %%
max_prediction_length = 3
max_encoder_length = 20
training_cutoff = data['time_idx'].max() - max_prediction_length

training = TimeSeriesDataSet(
    data[lambda x: x.time_idx <= training_cutoff],
    time_idx = 'time_idx',
    target = 'close_coinbase',
    group_ids = ['pairs'],
    min_encoder_length=max_encoder_length // 2,
    max_encoder_length=max_encoder_length,
    min_prediction_length=1,
    max_prediction_length=max_prediction_length,
    static_categoricals=['isholiday'],
    # static_reals = ['avg_population_2017', 'avg_yearly_household_income_2017'],
    time_varying_known_categoricals=['month'],
    time_varying_known_reals = ['time_idx'],
    time_varying_unknown_categoricals=[],
    time_varying_unknown_reals = [
        'diff',
        'diff_vix',
        # '20 Yr',
        # 'number_of_trades',
        'volume',
        'close', 
        'DCOILWTICO',
        # 'open_vix', 
        # 'close_vix',
    ] + [x for x in ['diff_coinbase'] if COINBASE],
    # target_normalizer = GroupNormalizer(
    #     groups = ['agency', 'sku'], transformation = 'softplus'
    # ),
    add_relative_time_idx = True,
    add_target_scales = True,
    add_encoder_length = True,
)

validation = TimeSeriesDataSet.from_dataset(training, data, predict=True, min_prediction_idx=training.index.time.max() + 1, stop_randomization=True)
test = TimeSeriesDataSet.from_dataset(training, data[-300:-1], predict=True, stop_randomization=True)



# %%


# %%
batch_size = 128
train_dataloader = training.to_dataloader(train=True, batch_size=batch_size, num_workers=0)
val_dataloader = validation.to_dataloader(train=False, batch_size=batch_size * 10, num_workers=0)
test_dataloader  = test.to_dataloader(train=False, batch_size=batch_size * 10, num_workers=0)

# %%
baseline_predictions = Baseline().predict(val_dataloader, return_y=True)
MAE()(baseline_predictions.output, baseline_predictions.y)

# %%
pl.seed_everything(42)
trainer = pl.Trainer(
    accelerator='gpu',
    gradient_clip_val=0.1,
)

# %%
tft = TemporalFusionTransformer.from_dataset(
    training,
    learning_rate = 0.03,
    hidden_size = 32,
    attention_head_size = 4,
    # dropout = 0.1,
    hidden_continuous_size = 32,
    loss = QuantileLoss([0.02, 0.1, 0.25, 0.04, 0.5, 0.75, 0.9, 0.98]),
    optimizer = "Adam",
)

print(f'Number of parameters in network : {tft.size()/1e3:.1f}')


# %%
from lightning.pytorch.tuner import Tuner

res = Tuner(trainer).lr_find(
    tft,
    train_dataloaders = train_dataloader,
    val_dataloaders = val_dataloader,
    max_lr = 10.0,
    min_lr = 1e-6,
)

print(f"suggested learning rate : {res.suggestion()}")
fig = res.plot(show=True, suggest=True)
fig.show()

# %%
# !pip install -U 'tensorboard'

# %%

early_stop_callback = EarlyStopping(
    monitor='val_loss', 
    min_delta=1e-4, 
    patience=10, 
    verbose=False, 
    mode='min'
)

lr_logger = LearningRateMonitor()
logger = TensorBoardLogger('lightning_logs')

trainer = pl.Trainer(
    max_epochs=500,
    accelerator = 'gpu',
    enable_model_summary=True,
    gradient_clip_val=0.1,
    limit_train_batches=50,
    # fast_dev_run=True,
    callbacks=[
        early_stop_callback, 
        lr_logger
    ],
    logger=logger,
    # max_steps = 1000,
)

trainer_dev = pl.Trainer(
    max_epochs=500,
    accelerator = 'gpu',
    enable_model_summary=True,
    gradient_clip_val=0.1,
    limit_train_batches=50,
    fast_dev_run=True,
    callbacks=[
        early_stop_callback, 
        lr_logger
    ],
    logger=logger,
    # max_steps = 1000,
)

tft = TemporalFusionTransformer.from_dataset(
    training,
    learning_rate = res.suggestion(),
    hidden_size = 16,
    attention_head_size = 2,
    dropout = 0.1,
    hidden_continuous_size = 8,
    loss = QuantileLoss(),
    log_interval = 10,
    optimizer = "Adam",
    reduce_on_plateau_patience = True,
)

# params = { 'hidden_size': 114, 'dropout': 0.18676198900702023, 'hidden_continuous_size': 2, 'attention_head_size': 1, 'learning_rate': 0.06326771037272999}
# tft.from_dataset(
#     training,
#     **params
# )

print(f"Number of parameters in network : {tft.size()/1e3:.1f}")

# %%
trainer.fit(tft, train_dataloader, val_dataloaders=val_dataloader)

# %%
for x in val_dataloader:
    print(x[1][0].shape)

# %%
# trainer_dev.fit(tft, train_dataloader, val_dataloaders=val_dataloader)

# %%
import pickle

from pytorch_forecasting.models.temporal_fusion_transformer.tuning import optimize_hyperparameters

# study = optimize_hyperparameters(
#     train_dataloader,
#     val_dataloader,
#     model_path='optuna_test',
#     n_trials = 10,
#     max_epochs = 50,
#     gradient_clip_val_range = (0.01, 1.0),
#     hidden_size_range = (8, 128),
#     hidden_continuous_size_range = (1, 4),
#     learning_rate_range = (0.001, 0.1),
#     dropout_range = (0.1, 0.3),
#     trainer_kwargs = dict(limit_train_batches=30),
#     reduce_on_plateau_patience = 4,
#     use_learning_rate_finder = False,
# )



# %%
best_model_path = trainer.checkpoint_callback.best_model_path
best_tft = TemporalFusionTransformer.load_from_checkpoint(best_model_path)


# %%
for x in val_dataloader:
    print(x)
    break

# %%
data.tail()

# %%
val_dataloader.dataset.data['reals'].shape

# %%
predict = best_tft.predict(test_dataloader, return_x = True ,return_y=True, mode='raw', trainer_kwargs = dict(accelerator="cpu"))
predict.output

# %%

predictions = best_tft.predict(val_dataloader, return_y=True, trainer_kwargs=dict(accelerator="cpu"))
MAE()(predictions.output, predictions.y)

# %%
raw_predictions = tft.predict(val_dataloader, mode='raw', return_x=True)

# %%
raw_predictions.output.prediction.shape

# %%
import matplotlib.pyplot as plt
import koreanize_matplotlib

for idx in range(1):
    plt.figure(dpi=200)
    tft.plot_prediction(raw_predictions.x, raw_predictions.output, idx=idx)
    plt.title("Coinbase 값")

# %%
# !pip install optuna-integration

# %%
# !pip install --no-cache --force optuna==3.4.0

# %%



