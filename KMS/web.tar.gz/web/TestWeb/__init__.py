from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

db = SQLAlchemy()
migrate = Migrate()


def create_app():
    app = Flask(__name__)
    app.config.from_pyfile('config.py')

    db.init_app(app)
    migrate.init_app(app, db)


    from . import model
    from .views import main_views

    app.register_blueprint(main_views.bp)
    
    @app.route('/')
    def index():
        return 'Hello World!'
    
    return app
    
    